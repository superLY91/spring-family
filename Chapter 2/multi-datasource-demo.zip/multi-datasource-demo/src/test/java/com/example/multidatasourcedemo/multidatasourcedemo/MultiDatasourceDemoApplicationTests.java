package com.example.multidatasourcedemo.multidatasourcedemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MultiDatasourceDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
